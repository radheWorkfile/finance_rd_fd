<div class="row">
    <div class="col-12">
        <label>Plan Name:<span class="text-danger">*</span></label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-network-wired"></i></span>
            </div>
            <input type="hidden" name="id" id="id" class="form-control" value="<?php echo $uprd['id'] ?>">
            <input type="text" name="plan_name" id="plan_name" class="form-control" value="<?php echo $uprd['plan_name'] ?>">
        </div>
    </div>
    <div class="col-12">
        <label>Duration:<span class="text-danger">*</span></label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-clock"></i></span>
            </div>
            <input type="text" name="duration" id="duration" class="form-control" value="<?php echo $uprd['duration'] ?>"><select class="form-control">
                <option>Months</option>
            </select>
        </div>
    </div>
    <div class="col-12">
        <label>Amount:<span class="text-danger">*</span></label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-money-bill"></i></span>
            </div>
            <input type="text" name="amount" id="amount" class="form-control" value="<?php echo $uprd['amount'] ?>">
        </div>
    </div>
    <div class="col-12">
        <label>Interest Percent:<span class="text-danger">*</span></label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-money-bill"></i></span>
            </div>
            <input type="text" name="interest_percent" id="interest_percent" class="form-control" value="<?php echo $uprd['interest_percent'] ?>">
        </div>
    </div>
    <div class="col-12">
        <label>Remark:</label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-check"></i></span>
            </div>
            <textarea type="text" name="remark" id="remark" class="form-control"><?php echo $uprd['remark'] ?></textarea>
        </div>
    </div>
</div>