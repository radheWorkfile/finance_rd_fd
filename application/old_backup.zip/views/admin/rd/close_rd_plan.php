<!-- Profile Image -->
<div class="card-body box-profile">
    <div class="row">
        <div class="col-6">
            <label>Member:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-rupee-sign"></i></span>
                </div>
                <input type="text" class="form-control" name="member_name" id="member_name" value="<?php echo $close_rd['nm']. "(" . $close_rd['u_id'] . ")"?>" readonly>
                <input type="hidden" class="form-control" name="rd_id" id="rd_id" value="<?php echo $close_rd['id'] ?>">
                <input type="hidden" class="form-control" name="user_id" id="user_id" value="<?php echo $close_rd['user_id'] ?>">
            </div>
        </div>
        <div class="col-6">
            <label>Rd Plan:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-rupee-sign"></i></span>
                </div>
                <input type="text" class="form-control" name="rd_plan" id="rd_plan" value="<?php echo $close_rd['p_nm'] ?>" readonly>
            </div>
        </div>
        <div class="col-6">
            <label>Total Amount:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-rupee-sign"></i></span>
                </div>
                <input type="text" class="form-control" name="total_amount" id="total_amount" value="<?php echo round((float)$total_amt) ?>" readonly>
            </div>
        </div>
        <div class="col-6">
            <label>Total Interest Amount:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-rupee-sign"></i></span>
                </div>
                <input type="text" class="form-control" name="total_interest_amount" id="total_interest_amount" value="<?php echo round((float)$interest_amt) ?>" readonly>
            </div>
        </div>
        <div class="col-6">
            <label>Interest Amount:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-money-check"></i></span>
                </div>
                <select name="interest_amt_permission" id="interest_amt_permission" class="form-control" onchange="return total_amt(this.value)">
                    <option value="">----Select One----</option>
                    <option value="1">Yes</option>
                    <option value="2">No</option>
                </select>
            </div>
        </div>
        <div class="col-6">
            <label>Paid Amount:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-rupee-sign"></i></span>
                </div>
                <input type="text" class="form-control" name="total_paid_amount" id="total_paid_amount" placeholder="Enter Paid Amount" readonly>
            </div>
        </div>
        <div class="col-6">
            <label>Mode Of Payment:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-money-check"></i></span>
                </div>
                <select name="mop" id="mop" class="form-control">
                    <option value="">----Select One----</option>
                    <option value="1">Online</option>
                    <option value="2">Cheque</option>
                    <option value="3">Cash</option>
                </select>
            </div>
        </div>
        <div class="col-6">
            <label>Paid date:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                </div>
                <input type="date" class="form-control" name="paid_date" id="paid_date" value="<?php echo date('Y-m-d') ?>">
            </div>
        </div>
        <div class="col-6">
            <label>Penalty Amount:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                </div>
                <input type="text" class="form-control" name="penalty_amount" id="penalty_amount" placeholder="Enter Penalty Amount">
            </div>
        </div>
        <div class="col-6">
            <label>Payment Remarks:<span class="text-danger">*</span></label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-money-check-alt"></i></span>
                </div>
                <textarea name="payment_remarks" id="payment_remarks" class="form-control"></textarea>
            </div>
        </div>
    </div>
</div>

<script>
    function total_amt(value) {
        var amount = $('#total_amount').val();
        var interest_amt = $('#total_interest_amount').val();
        var total_amt = parseInt(amount) + parseInt(interest_amt);
        if(value == 1) {
            $('#total_paid_amount').val(total_amt);
        } else if(value == 2) {
            $('#total_paid_amount').val(amount);
        }
    }
</script>