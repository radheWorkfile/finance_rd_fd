<div class="row">
    <div class="col-12">
        <label> Designation Name:<span class="text-danger">*</span></label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input type="hidden" class="form-control" name="id" id="id" placeholder="Enter Designation Name" value="<?php echo $desig['id'] ?>">
            <input type="text" class="form-control" name="designation_name" id="desi_name" placeholder="Enter Designation Name" value="<?php echo $desig['designation_name'] ?>">
        </div>
    </div>
</div>