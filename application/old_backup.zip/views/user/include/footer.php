<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="<?php echo $this->session->userdata('company_url')?>" target="_blank"><?php echo $this->session->userdata('company_name')?></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0
    </div>
</footer>

<aside class="control-sidebar control-sidebar-dark">
    Coming Soon!!
</aside>